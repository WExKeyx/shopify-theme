import React from 'react';
import { Monitor, Smartphone, Gamepad2, Tv } from 'lucide-react';

const PlatformIcons = () => {
  const platforms = [
    { name: 'Steam', icon: Monitor, color: 'text-blue-400' },
    { name: 'Epic Games', icon: Gamepad2, color: 'text-gray-300' },
    { name: 'PlayStation', icon: Tv, color: 'text-blue-500' },
    { name: 'Xbox', icon: Gamepad2, color: 'text-green-500' },
    { name: 'Nintendo', icon: Gamepad2, color: 'text-red-500' },
    { name: 'PC', icon: Monitor, color: 'text-gray-400' },
    { name: 'Mobile', icon: Smartphone, color: 'text-purple-400' },
    { name: 'VR', icon: Tv, color: 'text-pink-400' },
  ];

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="bg-gray-800/50 rounded-2xl p-8 backdrop-blur-sm border border-gray-700">
        <h2 className="text-2xl font-bold text-white text-center mb-8">Available Platforms</h2>
        <div className="grid grid-cols-4 md:grid-cols-8 gap-6">
          {platforms.map((platform, index) => {
            const IconComponent = platform.icon;
            return (
              <div
                key={index}
                className="flex flex-col items-center p-4 bg-gray-900/50 rounded-xl border border-gray-700 hover:border-purple-500 transition-all hover:transform hover:scale-105 cursor-pointer group"
              >
                <IconComponent className={`w-8 h-8 ${platform.color} group-hover:text-purple-400 transition-colors mb-2`} />
                <span className="text-sm text-gray-300 group-hover:text-white transition-colors text-center">
                  {platform.name}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default PlatformIcons;