import React from 'react';
import ProductCard from './ProductCard';

interface Product {
  id: number;
  title: string;
  price: string;
  xprimePrice: string;
  image: string;
  platform: string;
}

interface ProductGridProps {
  title: string;
  products: Product[];
}

const ProductGrid: React.FC<ProductGridProps> = ({ title, products }) => {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-3xl font-bold text-white">{title}</h2>
        <button className="text-purple-400 hover:text-purple-300 transition-colors font-medium">
          View All →
        </button>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </section>
  );
};

export default ProductGrid;