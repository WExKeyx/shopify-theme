import React, { useState } from 'react';
import { ShoppingCart, Star } from 'lucide-react';

interface Product {
  id: number;
  title: string;
  price: string;
  xprimePrice: string;
  image: string;
  platform: string;
}

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isXPrimeUser] = useState(Math.random() > 0.5); // Simulate XPrime status

  return (
    <div
      className="bg-gray-800/50 rounded-xl border border-gray-700 overflow-hidden hover:border-purple-500 transition-all duration-300 hover:transform hover:scale-105 cursor-pointer backdrop-blur-sm"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Product Image */}
      <div className="relative aspect-square overflow-hidden">
        <img
          src={product.image}
          alt={product.title}
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
        />
        
        {/* Platform badge */}
        <div className="absolute top-2 left-2 bg-gray-900/80 text-white text-xs px-2 py-1 rounded-md backdrop-blur-sm">
          {product.platform}
        </div>
        
        {/* Quick add button */}
        {isHovered && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <button className="bg-purple-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-purple-700 transition-colors flex items-center gap-2">
              <ShoppingCart className="w-4 h-4" />
              Quick Add
            </button>
          </div>
        )}
      </div>

      {/* Product Info */}
      <div className="p-4">
        <h3 className="text-white font-semibold mb-2 line-clamp-2 text-sm">
          {product.title}
        </h3>
        
        {/* Rating */}
        <div className="flex items-center mb-3">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className={`w-3 h-3 ${
                i < 4 ? 'text-yellow-400 fill-current' : 'text-gray-600'
              }`}
            />
          ))}
          <span className="text-gray-400 text-xs ml-2">(4.2)</span>
        </div>

        {/* Pricing */}
        <div className="space-y-2">
          {isXPrimeUser ? (
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs px-2 py-1 rounded-full font-bold">
                    XPrime
                  </span>
                  <span className="text-purple-400 font-bold">{product.xprimePrice}</span>
                </div>
                <span className="text-gray-500 text-sm line-through">{product.price}</span>
              </div>
            </div>
          ) : (
            <div>
              <div className="text-white font-bold mb-1">{product.price}</div>
              <div className="flex items-center gap-2">
                <span className="bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs px-2 py-1 rounded-full font-bold opacity-70">
                  XPrime
                </span>
                <span className="text-purple-400 text-sm">{product.xprimePrice}</span>
              </div>
              <span className="text-gray-500 text-xs">Subscribe to unlock</span>
            </div>
          )}
        </div>

        {/* Add to cart button */}
        <button className="w-full mt-4 bg-gray-700 text-white py-2 rounded-lg font-medium hover:bg-purple-600 transition-colors">
          Add to Cart
        </button>
      </div>
    </div>
  );
};

export default ProductCard;