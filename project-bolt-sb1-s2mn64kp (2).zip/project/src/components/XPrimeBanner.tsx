import React from 'react';
import { Star, Zap } from 'lucide-react';

interface XPrimeBannerProps {
  variant?: 'primary' | 'secondary';
}

const XPrimeBanner: React.FC<XPrimeBannerProps> = ({ variant = 'primary' }) => {
  const isPrimary = variant === 'primary';
  
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className={`relative overflow-hidden rounded-2xl ${
        isPrimary 
          ? 'bg-gradient-to-r from-purple-900 via-purple-800 to-pink-900' 
          : 'bg-gradient-to-r from-pink-900 via-purple-800 to-purple-900'
      }`}>
        {/* Background effects */}
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-purple-500/20 to-pink-500/20"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-white/5 rounded-full blur-3xl"></div>
        </div>
        
        <div className="relative flex flex-col lg:flex-row items-center justify-between p-8 lg:p-12">
          {/* Left content */}
          <div className="flex-1 text-center lg:text-left mb-8 lg:mb-0">
            <div className="flex items-center justify-center lg:justify-start mb-4">
              <Star className="w-8 h-8 text-yellow-400 mr-2" />
              <h2 className="text-4xl lg:text-6xl font-black text-white">
                SEAL<span className="text-purple-400">+</span>PASS
              </h2>
            </div>
            <p className="text-lg text-gray-200 mb-6 max-w-md">
              Get access to exclusive games and discounts. Premium gaming subscription.
            </p>
            <div className="flex items-center justify-center lg:justify-start mb-6">
              <span className="text-4xl font-bold text-white mr-2">€{isPrimary ? '1.99' : '2.09'}</span>
              <span className="text-gray-300">/month</span>
            </div>
            <button className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-8 py-3 rounded-full font-semibold hover:from-purple-600 hover:to-pink-600 transition-all transform hover:scale-105 shadow-lg">
              {isPrimary ? 'Subscribe Now' : 'Join XPrime'}
            </button>
          </div>

          {/* Right visual elements */}
          <div className="relative w-80 h-64">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-500/30 to-pink-500/30 rounded-full blur-2xl animate-pulse"></div>
            <div className="absolute top-4 right-4 w-16 h-16 bg-purple-500/50 rounded-full animate-bounce delay-300"></div>
            <div className="absolute bottom-8 left-8 w-12 h-12 bg-pink-500/50 rounded-full animate-bounce delay-700"></div>
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <Zap className="w-24 h-24 text-yellow-400 animate-pulse" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default XPrimeBanner;