import React from 'react';
import Header from './components/Header';
import HeroBanner from './components/HeroBanner';
import XPrimeBanner from './components/XPrimeBanner';
import PlatformIcons from './components/PlatformIcons';
import ProductGrid from './components/ProductGrid';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-gray-900">
      <Header />
      <main>
        <HeroBanner />
        <XPrimeBanner />
        <PlatformIcons />
        
        <ProductGrid 
          title="Best Selling Games" 
          products={bestSellingGames}
        />
        
        <ProductGrid 
          title="Best Selling Gift Cards" 
          products={giftCards}
        />
        
        <XPrimeBanner variant="secondary" />
        
        <ProductGrid 
          title="Trending Games" 
          products={trendingGames}
        />
        
        <ProductGrid 
          title="Popular Subscriptions" 
          products={subscriptions}
        />
        
        <ProductGrid 
          title="Premium Software" 
          products={premiumSoftware}
        />
        
        <ProductGrid 
          title="Upcoming Games" 
          products={upcomingGames}
        />
      </main>
      <Footer />
    </div>
  );
}

// Sample data matching the design
const bestSellingGames = [
  {
    id: 1,
    title: "Minecraft",
    price: "€26.95",
    xprimePrice: "€21.56",
    image: "https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  },
  {
    id: 2,
    title: "Red Dead Redemption 2",
    price: "€59.99",
    xprimePrice: "€47.99",
    image: "https://images.pexels.com/photos/3165335/pexels-photo-3165335.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  },
  {
    id: 3,
    title: "Rust",
    price: "€34.99",
    xprimePrice: "€27.99",
    image: "https://images.pexels.com/photos/194511/pexels-photo-194511.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  },
  {
    id: 4,
    title: "Among Us",
    price: "€4.99",
    xprimePrice: "€3.99",
    image: "https://images.pexels.com/photos/3945313/pexels-photo-3945313.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  },
  {
    id: 5,
    title: "Stardew Valley",
    price: "€13.99",
    xprimePrice: "€11.19",
    image: "https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  }
];

const giftCards = [
  {
    id: 6,
    title: "Steam Gift Card €10",
    price: "€10.00",
    xprimePrice: "€9.50",
    image: "https://images.pexels.com/photos/6963944/pexels-photo-6963944.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "Steam"
  },
  {
    id: 7,
    title: "PlayStation Gift Card €25",
    price: "€25.00",
    xprimePrice: "€23.75",
    image: "https://images.pexels.com/photos/4009599/pexels-photo-4009599.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PlayStation"
  },
  {
    id: 8,
    title: "Xbox Gift Card €15",
    price: "€15.00",
    xprimePrice: "€14.25",
    image: "https://images.pexels.com/photos/3945313/pexels-photo-3945313.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "Xbox"
  },
  {
    id: 9,
    title: "Nintendo eShop €20",
    price: "€20.00",
    xprimePrice: "€19.00",
    image: "https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "Nintendo"
  },
  {
    id: 10,
    title: "Epic Games €50",
    price: "€50.00",
    xprimePrice: "€47.50",
    image: "https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "Epic Games"
  }
];

const trendingGames = [
  {
    id: 11,
    title: "Cyberpunk 2077",
    price: "€59.99",
    xprimePrice: "€47.99",
    image: "https://images.pexels.com/photos/3165335/pexels-photo-3165335.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  },
  {
    id: 12,
    title: "Call of Duty",
    price: "€69.99",
    xprimePrice: "€55.99",
    image: "https://images.pexels.com/photos/194511/pexels-photo-194511.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  },
  {
    id: 13,
    title: "FIFA 24",
    price: "€69.99",
    xprimePrice: "€55.99",
    image: "https://images.pexels.com/photos/3945313/pexels-photo-3945313.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  },
  {
    id: 14,
    title: "Assassin's Creed",
    price: "€59.99",
    xprimePrice: "€47.99",
    image: "https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  },
  {
    id: 15,
    title: "The Witcher 3",
    price: "€39.99",
    xprimePrice: "€31.99",
    image: "https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  }
];

const subscriptions = [
  {
    id: 16,
    title: "Xbox Game Pass",
    price: "€12.99",
    xprimePrice: "€10.39",
    image: "https://images.pexels.com/photos/3165335/pexels-photo-3165335.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "Xbox"
  },
  {
    id: 17,
    title: "PlayStation Plus",
    price: "€8.99",
    xprimePrice: "€7.19",
    image: "https://images.pexels.com/photos/194511/pexels-photo-194511.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PlayStation"
  },
  {
    id: 18,
    title: "EA Play",
    price: "€4.99",
    xprimePrice: "€3.99",
    image: "https://images.pexels.com/photos/3945313/pexels-photo-3945313.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  },
  {
    id: 19,
    title: "Ubisoft+",
    price: "€14.99",
    xprimePrice: "€11.99",
    image: "https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  },
  {
    id: 20,
    title: "Apple Arcade",
    price: "€4.99",
    xprimePrice: "€3.99",
    image: "https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "Mobile"
  }
];

const premiumSoftware = [
  {
    id: 21,
    title: "Windows 11 Pro",
    price: "€259.00",
    xprimePrice: "€207.20",
    image: "https://images.pexels.com/photos/3165335/pexels-photo-3165335.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  },
  {
    id: 22,
    title: "Office 365",
    price: "€69.00",
    xprimePrice: "€55.20",
    image: "https://images.pexels.com/photos/194511/pexels-photo-194511.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  },
  {
    id: 23,
    title: "Adobe Creative Suite",
    price: "€239.88",
    xprimePrice: "€191.90",
    image: "https://images.pexels.com/photos/3945313/pexels-photo-3945313.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  },
  {
    id: 24,
    title: "Antivirus Premium",
    price: "€49.99",
    xprimePrice: "€39.99",
    image: "https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  }
];

const upcomingGames = [
  {
    id: 25,
    title: "Grand Theft Auto VI",
    price: "€79.99",
    xprimePrice: "€63.99",
    image: "https://images.pexels.com/photos/3165335/pexels-photo-3165335.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  },
  {
    id: 26,
    title: "Elder Scrolls VI",
    price: "€69.99",
    xprimePrice: "€55.99",
    image: "https://images.pexels.com/photos/194511/pexels-photo-194511.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  },
  {
    id: 27,
    title: "Starfield DLC",
    price: "€29.99",
    xprimePrice: "€23.99",
    image: "https://images.pexels.com/photos/3945313/pexels-photo-3945313.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  },
  {
    id: 28,
    title: "Diablo IV Expansion",
    price: "€39.99",
    xprimePrice: "€31.99",
    image: "https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "PC"
  },
  {
    id: 29,
    title: "Halo Infinite DLC",
    price: "€19.99",
    xprimePrice: "€15.99",
    image: "https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=400",
    platform: "Xbox"
  }
];

export default App;